def __module_version__():
	return 0, 0, 1 
