def module_version():
	return 1, 3, 10 
